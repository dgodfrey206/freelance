package treeAssign;

public interface Function<T> {
	public void forEach(Node<T> node);
}
