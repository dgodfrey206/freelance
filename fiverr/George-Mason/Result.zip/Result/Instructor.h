#ifndef INSTRUCTOR_H
#define INSTRUCTOR_H

struct Instructor {
    std::string name;
};

#endif
